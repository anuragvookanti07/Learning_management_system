# Studysphere Client

#### To run the client following conditions should be met

<ul>
    <li>Node js 15 should be installed</li>
    <li>Npm 10 or 9 should be installed</li>
</ul>

<b>Note: .npmrc file should not be changed</b>
