import React from 'react'
import MainCard from './../ui-component/cards/MainCard';

export default function MainBody(title) {
    return (
        <MainCard title={title}>

        </MainCard>
    )
}
