import React from 'react';
import MainCard from '../../../ui-component/cards/MainCard';
import CourseList from './courseList';
import ApproveCourse from '../../Admin/ApproveCourse';

export default function AdminDash() {
    return (
        <MainCard>
            {/* <CourseList /> */}
        </MainCard>
    );
}
