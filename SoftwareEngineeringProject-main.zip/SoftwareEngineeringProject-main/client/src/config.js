const config = {
    basename: '',
    defaultPath: '/login',
    fontFamily: `'Roboto', sans-serif`,
    borderRadius: 12,
    API_SERVER: 'http://localhost:5000/api/'
};

export default config;
